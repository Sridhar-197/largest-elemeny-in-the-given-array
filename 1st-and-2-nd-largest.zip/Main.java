import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc= new Scanner(System.in);
	    
	    System.out.println("ENTER THE VALUE OF N");
	    int n =sc.nextInt();
	    
	    
	     System.out.println("ENTER THE VALUE OF ARRAY");
	    
	    int arr[]=new int[n];
	    int l1=0;
	    int l2=0;
	    
	    
	    for(int i=0;i<n;i++)
	    {
	        arr[i]=sc.nextInt();
	    }
	      for(int i=0;i<n;i++)
	   {
	    
	        if(arr[i]>l1)
	        {
	             l2=l1;
	            l1=arr[i];
	           
	        }
	        else if(arr[i]>l2&&arr[i]<l1)
	        {
	            l2=arr[i];
	        }
	        
	   } 
	    	System.out.println("1 st largest number is "+ l1);
			System.out.println("2 nd  largest number is "+ l2);
		
	}
}
